import Link from 'next/link';

export default function Login() {
  return (
    <>
      <header className='flex pr-[3%] md:px-[6%] py-3 justify-between items-center'>
        <Link href="/"><a className='w-24'><img src='/assets/images/logo-black.png' alt='shieldedbit logo' /></a></Link>
        <span className='text-sm'>
          <em className='hidden sm:inline'>New to ShieldedBit? </em>
          <Link href="/register"><a className='py-1 px-3 ml-2 bg-black hover:bg-transparent transition-colors hover:text-black text-white border-black border-2 border-solid rounded'>Sign Up</a></Link>
        </span>
      </header>
      <main className='container mx-auto mt-20 flex place-content-center pb-14'>
        <form className='w-[380px] px-2 grid place-items-center '>
          <h2 className='text-4xl font-bold'>Login to ShieldedBit</h2>
          <p className='mb-8'>Welcome back! Please log in view your account.</p>
          <div className='py-2 w-full'>
            <label htmlFor='username'>Username</label>
            <input type='text' id='username' className='py-[10px] px-4' placeholder='Username'/>
          </div>
          <div className='py-2 w-full'>
            <label htmlFor='password' className='pr-2 flex justify-between items-center'>Password  <Link href='/'><a className='text-blue-400 text-xs hover:underline'>Forgot Password?</a></Link> </label>
            <input type='text' id='password' className='py-[10px] px-4' placeholder='Password'/>
          </div>

          <div className='p-2 w-full'>
            <button className='bg-blue-600 hover:bg-black hover:text-blue-600 text-lg font-bold transition-colors w-full py-3 rounded'> Log in to dashboard</button>
          </div>
        </form>
      </main>
    </>
  )
}
