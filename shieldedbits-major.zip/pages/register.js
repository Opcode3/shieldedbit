import Link from 'next/link'
import Step1 from '../components/forms/register/step1'
import Step2 from '../components/forms/register/step2'
export default function Register() {
  return (
    <>
      <header className='flex pr-[3%] md:px-[6%] py-3 justify-between items-center'>
        <Link href="/"><a className='w-24'><img src='/assets/images/logo-black.png' alt='shieldedbit logo' /></a></Link>
        <span className='text-sm'>
          <em className='hidden sm:inline'>Already have an account? </em>
          <Link href="/login"><a className='py-2 px-5 ml-2 bg-black hover:bg-transparent hover:text-black transition-colors text-white border-black border-2 border-solid rounded'>Log In</a></Link>
        </span>
      </header>
      <main className='container mx-auto mt-12 flex flex-col items-center pb-14'>
        {/* <h1 className='font-extrabold text-4xl uppercase'>Create your account</h1> */}
        <div className='mb-16'>
          <span className='w-3 h-2 bg-blue-700 rounded cursor-pointer inline-block'></span>
          <span className='w-3 h-2 bg-black rounded cursor-pointer mx-1 inline-block'></span>
          <span className='w-3 h-2 bg-black rounded cursor-pointer mr-1 inline-block'></span>
          <span className='w-3 h-2 bg-black rounded cursor-pointer inline-block'></span>
        </div>
          {/* <Step1 /> */}
        {/* <div className='bg-red-500 min-h-fit py-2 w-full'>
        </div> */}
        <Step2/>
      </main>
    </>
  )
}
