
export default function Home() {
  return (
    <div className="flex justify-center items-center bg-slate-500 h-screen">
      Home Page
    </div>
  )
}
