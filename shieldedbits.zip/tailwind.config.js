module.exports = {
  content: [
    "./pages/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      gridTemplateColumns:{
        'auto200': 'auto 200px',
        '100auto100': '100px auto 100px'
      },
      spacing:{
        '10%': '20px 10%',
        '8%': '20px 8%',
        '6%': '20px 6%'
      }
    },
  },
  plugins: [],
}
