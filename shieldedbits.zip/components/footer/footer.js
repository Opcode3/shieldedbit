
export default function Footer() {
  return (
    <div>footer</div>
  )
}
