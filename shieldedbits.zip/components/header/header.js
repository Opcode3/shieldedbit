import Link from "next/link";

export default function Header() {
  return (
    <header className="grid md:grid-cols-auto200 grid-cols-100auto100 min-h-fit p-6% lg:p-10% bg-black">
      <button className="md:hidden bg-white">
        <li></li>
        <li></li>
        <li></li>
      </button>
      <div className="flex justify-center">
        <img src="/assets/images/logo-white.jpeg" className="w-16 " alt="ShieldedBit Logo" />
        <nav className="hidden md:flex">
          <ul>
            <li> <Link href="/"> Home </Link> </li>
            <li> <Link href="/"> About </Link> </li>
            <li> <button> Services </button> 
                <ul>
                  <li> <Link href="/"> Consultancy</Link> </li>
                  <li> <Link href="/"> Staff Training</Link> </li>
                </ul>
            </li>
            <li> <Link href="/"> Contact Us</Link> </li>
          </ul>
        </nav>
      </div>
      <div className="">
        <ul className="flex justify-end mr-2">
          <li> <img src="/assets/images/100x100.jpg" className="md:w-8 w-10 rounded-full bg-red-600 my-2" alt="User Account" /> 
            <ul>
              <li> <Link href="/">Log In</Link> </li>
              <li> <Link href="/">Register</Link> </li>
            </ul>
          </li>
          <li className="ml-3 hidden md:block"> <Link href="/"><a className="hover:no-underline">Support Us</a></Link> </li>
        </ul>
      </div>
    </header>
  )
}
