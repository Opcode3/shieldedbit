module.exports = {
  content: [
    "./pages/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      // gridTemplateColumns:{
      //   'auto200': 'auto 200px',
      //   '100auto100': '100px auto 100px',
      //   '65auto250': '65px auto 250px',
      //   '100auto250': '100px auto 250px',
      //   '100auto': '300px auto',
      //   '40auto': '50px auto',
      //   '57auto': 'minmax(auto, 480px) minmax(540px, auto);',
      //   '107': 'repeat(3, minmax(0, 1fr)) 350px',
      // },
      // gridTemplateRows:{
      //   '160auto100': '140px auto 100px',
      //   'minauto': 'min-content  auto',
      // },
    },
  },
  plugins: [],
}
