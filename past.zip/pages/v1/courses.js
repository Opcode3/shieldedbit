import Head from "next/head";
import Layout from "../../components/dashboard/Layout";
import Tab from "../../components/dashboard/tab";
import Request from "../../helper/request";
import { useState, useContext } from "react";
import { useUserState } from "../../components/dashboard/admin";
import { useRouter } from "next/router";


export default function Courses() {

  // const { name } = useUserState();

  const router = useRouter();
  const {name, getUser} = useUserState();
  (getUser() === null) && router.push("/v1/login")


  const request = new Request();
  const [tabIndex, setTabIndex] =  useState(1);

  const tab_data = [
    {
      text: 'Add Course',
      tabIndex: tabIndex == 1,
      setTabIndex: () => setTabIndex(1)
    },
    {
      text: 'View Courses',
      tabIndex: tabIndex == 0,
      setTabIndex: () => setTabIndex(0)
    }
  ]

  // console.log(name)


  
  return (
      <>
        <Head>
            <title> Manage Courses - ShieldedBit</title>
        </Head>
        <Layout>
          <Tab items={tab_data}>
              {

                tabIndex == 0 ? <div> courses { request.post('url', '30') } </div>
                : <div>courses { request.get('https://jsonplaceholder.typicode.com/posts/3', '30') }</div>
              }
          </Tab>
        </Layout>
      </>
  )


}
