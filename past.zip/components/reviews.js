
export default function Reviews() {
  return (
    <div>reviews</div>
  )
}
