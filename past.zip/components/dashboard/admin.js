import { useRouter } from "next/router";
import React from "react"



const AdminContext = React.createContext({});


export function UserProvider({children}){
    const router = useRouter()

    function getUser(){
        return null;
    }

  if(router.pathname.includes('user') && getUser() === null){
    // router.r("/login")
  }

    const [name, setName] = React.useState("Dorathy");

    const state = {
        getUser,
        name,
        setName,
    }

    return (
        <AdminContext.Provider value={state}>
            {children}
        </AdminContext.Provider>
    )
} 

export function useUserState(){
    const state = React.useContext(AdminContext);

    if(state === undefined){
        throw new Error('useUserState must be used within the userProvider component')
    }
    return state;
}