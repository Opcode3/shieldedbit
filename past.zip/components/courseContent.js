
export default function CourseContent() {
  return (
    <div>courseContent</div>
  )
}
