
export default function AboutInstructor() {
  return (
    <div>aboutInstructor</div>
  )
}
