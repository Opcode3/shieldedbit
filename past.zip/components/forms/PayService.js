
export default function PayService() {
  return (
    <div>PayService</div>
  )
}
